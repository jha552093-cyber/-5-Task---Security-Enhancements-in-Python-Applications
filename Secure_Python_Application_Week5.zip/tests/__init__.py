"""
Test package initialization.
"""
